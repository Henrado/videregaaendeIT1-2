		<div class="Banner1">
            
                <div class="Banner">
                
                    <a href="Index.php" class="Banner">henmell</a>
			     
			     </div>
                
		</div>
		
	<div class="allmeny">		
		<!-- <div class="meny1"> -->
            <ul>
                <li>
                    <a href="produkterliste.php" class="dropbtn">Alle biler</a>
				</li>
				<li>
                    <a href="" class="dropbtn">Alle leietakere</a>
				</li>
				<li>
                    <a href="" class="dropbtn">Hvem er vi?</a>
				</li>
				<li>
                    <a href="" class="dropbtn">Administrator</a>
                </li>
            </ul>
	</div>