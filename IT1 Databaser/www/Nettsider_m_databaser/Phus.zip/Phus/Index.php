<!doctype html>
<html>

    <head>
        <title>Phus</title>
        <meta charset="UTF-8">  
        <link rel="stylesheet" type="text/css" href="./php/test.css">
        
    </head>

    <body>
        
        
        <div class="Main">
        <?php
        
            include "./php/tilkobling.php";
			
            include "./php/bannerogmeny.php";
            ?>
		
			<div class="Innhold">
			<h1>Dagens anbefalte produkt</h1>
			
		<?php
			//header ("refresh:0;");
		?>
			</div>
		</div>
    </body>
</html>