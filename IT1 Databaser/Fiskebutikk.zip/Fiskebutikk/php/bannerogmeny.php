			<div class="registrer">
                <a href="legge_til_bruker.php">Registrer deg som kunde hos oss nå!</a>
            </div>
            
		<div class="Banner1">
            
                <div class="Banner">
                
                    <a href="Index.php" class="Banner">henmell</a>
			     
			     </div>
                
		</div>
		
	<div class="allmeny">		
		<!-- <div class="meny1"> -->
            <ul>
                <li class="dropdown">
                    <a href="produkterliste.php" class="dropbtn">Produkter</a>
                <div class="dropdown-content">
                    <a href="produkterliste.php">Fiskestenger</a>
                    <a href="produkterliste.php">Tråd</a>
                    <a href="produkterliste.php">Agn</a>
                    <a href="produkterliste.php">Kroker</a>
                    <a href="produkterliste.php">Hatter</a>
                </div>
				</li>
			</ul>
		<!-- <div class="meny2"> -->
			<ul>
				<li class="dropdown">
                    <a href="" class="dropbtn">Hvordan Fiske</a>
                <div class="dropdown-content">
                    <a href="#">Tips</a>
                    <a href="#">Fiskesteder</a>
                </div>
				</li>
			</ul>
		<!-- <div class="meny3"> -->
			<ul>
                <li class="dropdown">
                    <a href="" class="dropbtn">Hvem er vi?</a>
                <div class="dropdown-content">
                    <a href="#">Om oss</a>
                    <a href="#">Kontakt oss</a>
                </div>
				</li>
			</ul>
		<!-- <div class="meny4"> -->
			<ul>
				<li class="dropdown">
                    <a href="" class="dropbtn">Administrator</a>
                <div class="dropdown-content">
                    <a href="kunder.php">Alle kunder</a>
                    <a href="registrerte_produkter.php">Alle bestillinger</a>
                </div>
                </li>
            </ul>
	</div>
            <!-- <div class="søke">
                <form>
                    <input type="text" name="search" placeholder="Søk etter produkt">
                </form>
            </div>
				
			--!>